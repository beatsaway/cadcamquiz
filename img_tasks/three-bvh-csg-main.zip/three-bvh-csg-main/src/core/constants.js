export const ADDITION = 0;
export const SUBTRACTION = 1;
export const REVERSE_SUBTRACTION = 2;
export const INTERSECTION = 3;
export const DIFFERENCE = 4;

// guaranteed non manifold results
export const HOLLOW_SUBTRACTION = 5;
export const HOLLOW_INTERSECTION = 6;
