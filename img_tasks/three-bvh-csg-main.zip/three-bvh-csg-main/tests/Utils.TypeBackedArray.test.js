describe( 'TypeBackedArray', () => {

	it.todo( 'make tests' );

} );
