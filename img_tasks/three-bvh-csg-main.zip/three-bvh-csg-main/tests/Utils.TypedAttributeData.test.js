describe( 'TypedAttributeData', () => {

	it.todo( 'make tests' );

} );
